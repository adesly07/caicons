      <!-- Third Row (Footer) -->
<footer class="p-4 bg-sky-400 text-white text-center">
    <p class="mt-2 text-white">&copy; CAICONS, 2023-<?php echo date("Y"); ?>. All rights reserved.</p>
    <p><a href ="#">Powered by CAICONS ICT Unit</a></p>
</footer>